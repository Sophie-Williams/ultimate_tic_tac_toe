
#include "ult_ttt_master.h"

int main() {
    UltTTTMaster master;
    master.play();
    return 0;
}
