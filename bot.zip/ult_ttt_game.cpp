

#include <vector>

#include "ult_ttt_game.h"

UltTTTGame::UltTTTGame() { };

UltTTTGame::~UltTTTGame() { };

void UltTTTGame::set_round(const int& n) { __round = n; }

void UltTTTGame::set_move(const int& n) { __move = n; }

void UltTTTGame::set_field(const std::vector<int>& f) { __field = f; }

void UltTTTGame::set_macro(const std::vector<int>& m) { __macro = m; }

int UltTTTGame::get_round() { return __round; }

int UltTTTGame::get_move() { return __move; }

std::vector<int> UltTTTGame::get_field() { return __field; }

std::vector<int> UltTTTGame::get_macro() { return __macro; }
